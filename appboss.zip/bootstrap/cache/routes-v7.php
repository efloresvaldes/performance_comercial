<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/under_construction' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XT6NbTLhRBqf7Jeu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/test' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cR4ILUFPIOUGdGpr',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/con_desempenho' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sl7pXfQ2WtqWDbYQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/con_desempenho_res' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::29Xv4XvdpbOn9bHc',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/con_desempenho_graf' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VT4AfWX1eXXfu0oO',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/con_desempenho_pie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0Z1YqkwqqOvtlGZL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LZ2T6CdllDDX97d5',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
    ),
    3 => 
    array (
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::XT6NbTLhRBqf7Jeu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'under_construction',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:273:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:55:"function () {
    return \\view(\'under_construction\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000004931bfc3000000005b381a1f";}";s:4:"hash";s:44:"qtVaHzfAyVnZEJ1k3eEUHJYrS38vFVLZUWHvjiGyctQ=";}}',
        'namespace' => 'App\\Http\\PerformanceComercialController',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::XT6NbTLhRBqf7Jeu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cR4ILUFPIOUGdGpr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'test',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PerformanceComercialController@test',
        'controller' => 'App\\Http\\Controllers\\PerformanceComercialController@test',
        'namespace' => 'App\\Http\\PerformanceComercialController',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::cR4ILUFPIOUGdGpr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sl7pXfQ2WtqWDbYQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'con_desempenho',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PerformanceComercialController@performanceComercialHome',
        'controller' => 'App\\Http\\Controllers\\PerformanceComercialController@performanceComercialHome',
        'namespace' => 'App\\Http\\PerformanceComercialController',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::sl7pXfQ2WtqWDbYQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::29Xv4XvdpbOn9bHc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'con_desempenho_res',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PerformanceComercialController@performanceComercialReport',
        'controller' => 'App\\Http\\Controllers\\PerformanceComercialController@performanceComercialReport',
        'namespace' => 'App\\Http\\PerformanceComercialController',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::29Xv4XvdpbOn9bHc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VT4AfWX1eXXfu0oO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'con_desempenho_graf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PerformanceComercialController@generateBarChart',
        'controller' => 'App\\Http\\Controllers\\PerformanceComercialController@generateBarChart',
        'namespace' => 'App\\Http\\PerformanceComercialController',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::VT4AfWX1eXXfu0oO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0Z1YqkwqqOvtlGZL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'con_desempenho_pie',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PerformanceComercialController@generatePieChart',
        'controller' => 'App\\Http\\Controllers\\PerformanceComercialController@generatePieChart',
        'namespace' => 'App\\Http\\PerformanceComercialController',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::0Z1YqkwqqOvtlGZL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LZ2T6CdllDDX97d5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:api',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:295:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000004931bfd4000000005b381a1f";}";s:4:"hash";s:44:"JR5hdUCv1sDmhO4rBcZZW/F5w2v9pmqGnc+O23dlxLY=";}}',
        'namespace' => 'App\\Http\\PerformanceComercialController',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::LZ2T6CdllDDX97d5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
